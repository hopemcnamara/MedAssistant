Username: user
Password: pass
Select Symptoms to get diagnosis: Nausea, Congestion, Fever, Chills, Tired
Select no symptoms to get healthy diagnosis
Select other variations to get unknown.
More diagnoses will be added in the future 
